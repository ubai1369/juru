/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.juru.parking.models;

import java.util.Date;

/**
 *
 * @author ubai
 */
public class Mobil extends Kendaraan {
    public Mobil(String platNomor) {
        super(200, "Mobil", platNomor);
    }
}
