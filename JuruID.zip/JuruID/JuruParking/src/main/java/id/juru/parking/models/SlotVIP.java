/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.juru.parking.models;

import java.util.ArrayList;

/**
 *
 * @author ubai
 */
public class SlotVIP extends ParkingSlotBase<VIP>{
    public SlotVIP() {
        this.listKendaraan = new ArrayList<>();
        this.listKendaraanKeluar = new ArrayList<>();
        this.maxSlot = 2;
        this.prefixKodeParkir = "VIP";
    }
}
