/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.juru.parking.models;

import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author ubai
 * Base dari semua jenis kendaraan
 */
public abstract class Kendaraan {
    
    final int hargaPerjam;
    final String jenisKendaraan;
    final String platNomor;
    private String kodeParkir;
    private final Date kendaraanMasuk;
    protected Date kendaraanKeluar;
   
    public Kendaraan(int hargaPerjam, String jenisKendaraan, String platNomor) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        this.hargaPerjam = hargaPerjam;
        this.jenisKendaraan = jenisKendaraan;
        this.platNomor = platNomor;
        this.kendaraanMasuk = cal.getTime();
    }
    
    public String getKodeParkir() {
        return kodeParkir;
    }

    public void setKodeParkir(String kodeParkir) {
        this.kodeParkir = kodeParkir;
    }
    
    public String getPlatNomor() {
        return platNomor;
    }

    public int getHargaPerjam() {
        return hargaPerjam;
    }

    public String getJenisKendaraan() {
        return jenisKendaraan;
    }
    
    public Date getKendaraanMasuk() {
        return kendaraanMasuk;
    }

    public Date getKendaraanKeluar() {
        return kendaraanKeluar;
    }
    
    public void setKendaraanKeluar(Date kendaraanKeluar) {
        this.kendaraanKeluar = kendaraanKeluar;
    }
    
    public int getTotalHarga() {
        if (kendaraanKeluar != null) {

            long diff = kendaraanKeluar.getTime() - kendaraanMasuk.getTime();

            long minutes = TimeUnit.MILLISECONDS.toMinutes(diff); 
    
            return (int) (minutes * this.hargaPerjam);
        } else {
            return 0;
        }
    }
}
