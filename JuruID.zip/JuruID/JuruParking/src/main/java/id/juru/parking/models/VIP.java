/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.juru.parking.models;

/**
 *
 * @author ubai
 */
public class VIP extends Kendaraan {
    public VIP(String platNomor) {
        super(500, "VIP", platNomor);
    }
}
