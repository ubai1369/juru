/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.juru.parking.models;

import java.util.Date;
import java.util.List;

/**
 *
 * @author ubai
 * Models untuk slot parkir berdasarkan kendaraan
 */
abstract class ParkingSlotBase<T extends Kendaraan> {
    protected List<T> listKendaraan;
    protected List<T> listKendaraanKeluar;
    protected int maxSlot;
    protected String prefixKodeParkir;
    private int lastParkingSlot = 1;

    public List<T> getListKendaraan() {
        return listKendaraan;
    }

    public List<T> getListKendaraanKeluar() {
        return listKendaraanKeluar;
    }
    
    public void kendaraanMasuk(T kendaraan) throws Exception {
        if (listKendaraan.size() >= maxSlot) {
            throw new Exception("Parkir Penuh");
        }
        
        kendaraan.setKodeParkir(this.prefixKodeParkir + lastParkingSlot);
        
        this.lastParkingSlot = this.lastParkingSlot + 1;
        
        listKendaraan.add(kendaraan);
    }
    
    public Kendaraan kendaraanKeluar(String platNomor, Date date) throws Exception {
        
        Kendaraan found = null;
        int foundIndex = -1;
        
        for (int i = 0; i < listKendaraan.size(); i++) {
            found = listKendaraan.get(i);
            
            if (found.platNomor.equals(platNomor)) {
                foundIndex = i;
            }
        }
        
        if (foundIndex > -1) {
            found.setKendaraanKeluar(date);
            listKendaraan.remove(foundIndex);
            return found;
        } else {
            return null;
        }
        
        
    }
    
    public int getMaxSlot() {
        return maxSlot;
    }
}
