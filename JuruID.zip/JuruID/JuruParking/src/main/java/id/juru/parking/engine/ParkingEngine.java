/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.juru.parking.engine;

import id.juru.parking.models.SlotMobil;
import id.juru.parking.models.SlotMotor;
import id.juru.parking.models.SlotVIP;

/**
 *
 * @author ubai
 * Singleton class, digunakan untuk pembuatan object yang hanya sekali dibuat
 * selama aplikasi berjalan
 */
public class ParkingEngine {
    
    private static ParkingEngine instance;
    
    private final SlotMobil slotMobil;
    private final SlotMotor slotMotor;
    private final SlotVIP slotVIP;
    
    private ParkingEngine() {
        this.slotMobil = new SlotMobil();
        this.slotMotor = new SlotMotor();
        this.slotVIP = new SlotVIP();
    }
    
    public static ParkingEngine getInstance() {
        if (instance == null) {
            instance = new ParkingEngine();
        }
        
        return instance;
    }
    
    public SlotMobil getSlotMobil() {
        return slotMobil;
    }

    public SlotMotor getSlotMotor() {
        return slotMotor;
    }

    public SlotVIP getSlotVIP() {
        return slotVIP;
    }
    
}
